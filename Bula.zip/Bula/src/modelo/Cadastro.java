package modelo;

public class Cadastro {
    
    String marca;
    String nome;
    String tdm;
    String rms;
    String ean;
    String ativo;
    String formas;
    String viadeadm;
    String unidade;
    String consumidor;    
    
    String cpf;
    String crf;
    String cnae;
    String visa;
    
    public String getRms() {
        return rms;
    }
    public void setRms(String rms) {
        this.rms = rms;
    }
    public String getEan() {
        return ean;
    }
    public void setEan(String ean) {
        this.ean = ean;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    } 
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    } 
    public String getTdm() { 
        return tdm;
    } 
    public void setTdm(String tdm) { 
        this.tdm = tdm;
    } 
    public String getAtivo() { 
        return ativo;
    } 
    public void setAtivo(String ativo) { 
        this.ativo = ativo;
    } 
    public String getFormas() { 
        return formas;
    } 
    public void setFormas(String formas) { 
        this.formas = formas;
    } 
    public String getViadeadm() {
        return viadeadm;
    }
    public void setViadeadm(String viadeadm) {
        this.viadeadm = viadeadm;
    }
    public String getUnidade() {
        return unidade;
    }
    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }
    public String getConsumidor() {
        return consumidor;
    }
    public void setConsumidor(String consumidor) {
        this.consumidor = consumidor;
    }    
    
    public String getCPF() {
        return cpf;
    }
    public void setCPF(String cpf) {
        this.cpf = cpf;
    }
    public String getCRF() {
        return crf;
    }
    public void setCRF(String crf) {
        this.crf = crf;
    }
    public String getCNAE() {
        return cnae;
    }
    public void setCNAE(String cnae) {
        this.cnae = cnae;
    }
    public String getVISA() {
        return visa;
    }
    public void setVISA(String visa) {
        this.visa = visa;
    }
    

}