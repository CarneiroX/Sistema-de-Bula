package dao;

import factory.ConnectionFactory;
import modelo.Cadastro;
import java.sql.*;
import java.sql.PreparedStatement;

public class CadastroDAO { 
    private Connection connection;
    
    String marca;
    String nome;
    String tdm;
    String rms;
    String ean;
    String ativo;
    String formas;
    String viadeadm;
    String unidade;
    String consumidor;  
    
    public CadastroDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Cadastro bula){ 
        
        String sql = "INSERT INTO bula(Marca,Nome,Tipo_de_Medicamento,Registo_MS,EAN,Princípio_Ativo,Formas_Farmacêuticas,Via_de_Administração,Unidade_de_Medida,Consumidor) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, bula.getMarca());
            stmt.setString(2, bula.getNome());
            stmt.setString(3, bula.getTdm());
            stmt.setString(4, bula.getRms());
            stmt.setString(5, bula.getEan());
            stmt.setString(6, bula.getAtivo());
            stmt.setString(7, bula.getFormas());
            stmt.setString(8, bula.getViadeadm());
            stmt.setString(9, bula.getUnidade());
            stmt.setString(10, bula.getConsumidor());            
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
    
}

