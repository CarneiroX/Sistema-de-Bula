package dao;

import factory.ConnectionFactory;
import modelo.Cadastro;
import java.sql.*;
import java.sql.PreparedStatement;

public class FuncionarioDAO { 
    
    private Connection connection;
    
    String cpf;
    String crf;
    String cnae;
    String visa;
    
    public FuncionarioDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Cadastro funcionarios){ 
        
        String sql = "INSERT INTO funcionarios(cpf,crf,cnae,visa) VALUES(?,?,?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, funcionarios.getCPF());
            stmt.setString(2, funcionarios.getCRF());
            stmt.setString(3, funcionarios.getCNAE());
            stmt.setString(4, funcionarios.getVISA());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
    
}